# Disease Classifier
Using a Naive Bayes Classifier gets possible diseases from symptoms
In 12 lines of code

### Example Input:
```
python GuessDisease.py "agit

### Requsites
```
sudo pip install naiveBayesClassifier
```

### Posible Bugs/Errors.
None that im aware of

### make app termux


### Thanks to:
seno kidal.
